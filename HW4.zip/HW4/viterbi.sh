#!/bin/bash

# Uncomment the line below if you write a Java program
# java viterbi $1 $2 $3 $4

# Uncomment the line below for a Python program
python viterbi.py $1 $2 $3 $4

# Uncomment the line below to run a compiled C or C++ program
#./viterbi $1 $2 $3 $4

# Uncomment the line below for a Perl programw
#perl viterbi.pl $1 $2 $3 $4

# Uncomment the line below for an R program
#Rscript viterbi.R $1 $2 $3 $4
 