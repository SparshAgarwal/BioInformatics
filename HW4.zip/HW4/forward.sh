#!/bin/bash

# Uncomment the line below if you write a Java program
# java forward $1 $2 $3 $4

# Uncomment the line below for a Python program
python forward.py $1 $2 $3 $4

# Uncomment the line below to run a compiled C or C++ program
#./forward $1 $2 $3 $4

# Uncomment the line below for a Perl program
#perl forward.pl $1 $2 $3 $4

# Uncomment the line below for an R program
#Rscript forward.R $1 $2 $3 $4
 